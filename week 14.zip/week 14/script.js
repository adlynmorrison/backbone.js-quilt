//JavaScript Document
;(function($) {
	'use strict';
	var nyt_config = {
		article_container: $('#articles'),
		article_headline: $('#article-headline'),
		article_pub_date: $('#article-pub-date'),
		article_main: $('#article-main'),
		article_source: $('#article-source'),
		article_word_count: $('#article_word_count'),
		article_template: $('#articles-template')
	};
})(window.jQuery);