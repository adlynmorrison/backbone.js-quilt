var TileApp = window.TileApp || {};

TileApp.TileView = Backbone.View.extend({
	tagName: 'li',
	className: 'tile',
	template:  _.template($('#tile-template').html()),
	
	events:{
		'click .feature': 'feature_tile',
		'click .view': 'view_tile',
		'click .delete': 'delete_tile'
	},
	
	feature_tile: function(e){
		e.preventDefault();
		
		this.model.set('featured', true);
		this.model.save();
		this.$el.addClass('featured');
	},
	
	view_tile: function(e){
		e.preventDefault();
		
		this.model.set('expanded', true);
		this.model.save();
		this.$el.addClass('expanded');
	},
	
	delete_title: function(e) {
		e.preventDefault();
		
		if (this.model.get('feature') || confirm('Are you sure you want to delete this title?')){
		this.model.destroy();
		
		this.$el.slideUp('fast', function() {
			this.remove();
			});
		}
	},
	
	render: function(){
		this.$el.html(this.template(this.model.toJson()));
		
		if (this.model.get('featured')){
			this.$el.addClass('featured');
		}
		
		if (this.model.get('expanded')){
			this.$el.addClass('expanded');
		}
		
		return this
	}
	
});