//set up our namespace
var TileApp = window.TileApp || {};

//create a collection to hold all the tiles
TileApp.TileCollection = Backbone.Collection.extend({
	//tell the collection what model to use
	model: TileApp.TileModel,
	
	//specify local storage insteal of a URL
	localStorage: new Backbone.LocalStorage('tile-app'),
	
	// function to return only completed titles
	feature: function(){
		//filter is the underscore message it gives
		return this.filter(function(tile){
			// if the title is featured, add it to
			// the return array
			return tile.get('feature');
		});
	},
	
	expanded: function(){
		//filter is the underscore message it gives you
		return this.filter(function(tile) {
			//if the todo is 'expanded, add it to
			// the return array
			return tile.get('expanded');
		});
	}
});

TileApp.Tiles = new TileApp.TileCollection();