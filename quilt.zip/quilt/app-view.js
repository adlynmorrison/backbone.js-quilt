//set up our namespace
var TileApp = window.TileApp || {};
	
	//create a new application view
TileApp.AppTile = Backbone.View.extend ({
	//boundries of the our application -it will
	//operate inside the element specified below
	el: $('tile-app'),
	
	//set up out event handlers
	events: {
		'click #create-tile': 'create_tile'
	},
	
	//automatically called when the app view is
	//instantiated
	initialize: function() {
		//reference the title list
		this.$tile_list = ('#tile-list');
		
		//get a reference to our form elements
		this.$form = ('#tile-form');
		this.$source = ('#source');
		this.$caption = ('#caption');
		this.$featured = ('#featured');
		this.$order = ('#order');
		
		//get a reference too our stats elements
		this.$count_featured = $('#count-featured');
		this.$count_remaining = $('#count-remaining');
		
		//make this application view listen for tiles
		//added to out collection
		this.listenTo(TileApp.Tiles, 'add', this.add_tile);
		
		//listen for *Any* Change on the collection
		// and run the 'render_stats' function
		this.listenTo (TileApp.Tiles, 'all', this.render_status)
		
		// get all existing tiles saved in localStorage
		// this 'fetch' call will work with localStorage
		// as well as URLS/APIs
		TileApp.Tiles.fetch();
	},
	
	//update featured and remaining counts at the top
	//of the form list
	render_stats: function(){
		//get the number number of featured tiles
		var featured = Tile.App.Tiles.featured().length;
		
		//get the total number of remaining titles that
		//can be on the quilt
		var remaining = TileApp.Tile.remaining().length;
		
		//update on the display
		this.$count_featured.text(featured);
		this.$count_remaining.text(remaining);
	},
	
	add_tile: function(tile){
		//create and instance of the view
		var view = new TileApp.TileView({ model: tile });
		
		this.$todo_list.append(view.render().el);
	},
	
	//handle clicks on #create-tile
	create_tile: function(e) {
		//reference the tile list
		e.preventDeFault();
		
		var tile_values = {
			tile: this.$tile.val(),
			source: this.$source.val(),
			caption: this.$caption.val(),
			featured: this.$featured.is(':checked'),
		};
		
		//add this new title to our collection
		TileApp.Tiles.create(title_values);
		
		console.log(TileApp.Tile);
		
		//reset the form
		this.$form[0].reset();
	}

});
	
window.TileAppView = new TileApp.AppTile();