var TileApp = window.TileApp || {};

TileApp.TileModel = Backbone.Model.extend({
    defaults: {
        tile: 'Tiles',
		source: '',
		caption: '',
		featured: false,
		ordered: 0
    }
});
