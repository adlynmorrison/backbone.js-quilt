//set up our namespace
var ToDoApp = window.TodoApp || {};

//create a new application view 
TodoApp.AppView = Backbone.View.extend ({
	//boundries of our application - it will
	//operate inside the element specified below
	el: $('#todo-app'),
	
	//set up our event handlers
	events: {
		'click #create-todo' : 'create_todo'
	},
	
	//automatically called when the app view is
	//instantiated
	initialize: function() { 
		//reference the todo list
		this.$todo_list = $('#todo-list');
	
		// get a reference to our form elements
		this.$form = $('#todo-form');
		this.$tile = $('#title');	
		this.$due = $('#due');
		this.$notes = $('#notes');
		this.$important = $('#important');
		
		//make this application view listen for todos
		//added to our collection
		this.listenTo(TodoApp.Todos, 'add', this.add_todo);
	},
	
	add_todo: function(todo){
		//create and instance of the view
		var view = new TodoApp.TodoView({ model: todo });
		
		this.$todo_list.append(view.render().el);
	},
	
		//handle clicks on #create-todo
		create_todo: function(e) {
			//reference the todo list
			this.$todo_list = $('todo-list');
			
			e.preventDefault();
			
			var todo_values = {
				title: this.$tile.val(),
				notes: this.$notes.val(),
				due: this.$notes.val(),
				important: this.$important.is(':checked')
			};
			
			// add this new todo to our collection
			TodoApp.Todos.create(todo_values);
			
			console.log(TodoApp.Todos);
			
			//reset the form
			this.$form[0].reset();
		}
});

//create an instance of our application view
//this instance acts as the ignition switch
//of our application
window.TodoAppView = new TodoApp.AppView();