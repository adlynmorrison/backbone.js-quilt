// set up our namespace
var TodoApp = window.TodoApp ||{};

// create a collection to hold all the todos
TodoApp.TodoCollection = Backbone.Collection.extend({
	// tell the collection what model to use
	model: TodoApp.TodoModel,
	
	// specify local storage instead of a URL
	localStorage: new Backbone.LocalStorage('todo-app')
});

// create an instance of our collection
TodoApp.Todos = new TodoApp.TodoCollection();